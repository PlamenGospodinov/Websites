<style>
	h1{
		font-size: 48px;
		color: orange;
	}
</style>


<?php

	get_header();
?>

<?php

	if(have_posts()){
		while(have_posts()){
			the_post();
		}
	}
?>

<h1><?php the_title();?></h1>
<div id="content">
	<?php the_content();?>
</div>

<?php

	

?>


<?php

	get_footer();
?>
