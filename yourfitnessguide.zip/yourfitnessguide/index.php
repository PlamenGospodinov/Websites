   <?php
        get_header();
   ?>


    

    <!-- ***** Features Item Start ***** -->
    <section id = "programs" class="section" id="features">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="section-heading">
                        <h2 >Choose a <em>Program</em></h2>
                        <img src="<?php bloginfo('template_directory'); ?>/images/line-dec.png" alt="waves">
                        <p>Here you can choose a program that suits your needs.</p>
                    </div>
                </div>



                <div class="col-lg-6">

                    <ul class="features-items">


                        <?php query_posts('cat=3'); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>



                        <li class="feature-item">
                            <div class="left-icon">
                                <img src="<?php bloginfo('template_directory'); ?>/images/features-first-icon.png" alt="First One">
                            </div>
                            <div class="right-content">
                                <h4><?php the_title(); ?></h4>
                                <p><?php echo the_content(); ?></p>
                                <a href="<?php the_permalink(); ?>" class="text-button">Discover More</a>
                            </div>
                        </li>
                       


                        <?php 
                        endwhile;
                        endif;
                    ?>

                    </ul>



                </div>
            </div>
        </div>
    </section>
    <!-- ***** Features Item End ***** -->

    <!-- ***** Call to Action Start ***** -->
    <section class="section" id="call-to-action">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="cta-content">
                        <h2>Don’t <em>think</em>, begin <em>today</em>!</h2>
                        <p>Reach new heights.Become the best version of yourself!</p>
                        <div class="main-button scroll-to-section">
                            <a href="#our-classes">Become a member</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Call to Action End ***** -->






    <!-- ***** Our Classes Start ***** -->
    <section class="section" id="our-classes">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="section-heading">
                        <h2>The Essential 4: Exercises That Will Get You <em>Ripped</em></h2>
                        <img src="<?php bloginfo('template_directory'); ?>/images/line-dec.png" alt="">
                        <p>Here are listed 4 of the most essential exercises everyone should start doing.They are very effective because you train multiple muscles at once when you execute them and they guarantee results.</p>
                    </div>
                </div>
            </div>
            <div class="row" id="tabs">
              <div class="col-lg-4">
                <ul>
                  <li><a href='#tabs-1'><img src="<?php bloginfo('template_directory'); ?>/images/tabs-first-icon.png" alt="">Squat</a></li>
                  <li><a href='#tabs-2'><img src="<?php bloginfo('template_directory'); ?>/images/tabs-first-icon.png" alt="">Deadlift</a></a></li>
                  <li><a href='#tabs-3'><img src="<?php bloginfo('template_directory'); ?>/images/tabs-first-icon.png" alt="">Barbell bench press</a></a></li>
                  <li><a href='#tabs-4'><img src="<?php bloginfo('template_directory'); ?>/images/tabs-first-icon.png" alt="">Pull up</a></a></li>
                  <div class="main-rounded-button"><a href="#">Go to the beginning</a></div>
                </ul>
              </div>
              <div class="col-lg-8">
                <section class='tabs-content'>
                  <article id='tabs-1'>
                    <img src="<?php bloginfo('template_directory'); ?>/images/squat.jpg" alt="First Class">
                    <h4>Squat</h4>
                    <p>The squat is a dynamic strength training exercise that requires several muscles in your upper and lower body to work together simultaneously.To do a basic squat: 

                    1.Start with your feet slightly wider than hip-width apart.  
                    2.Keep your chest up, engage your abdominals, and shift your weight onto your heels as you push your hips back into a sitting position.  
                    3.Lower your hips until your thighs are parallel or almost parallel to the floor.  
                    4.You should feel the squat in your thighs and glutes.  
                    5.Pause with your knees over, but not beyond, your toes. 
                    6.Exhale and push back up to the starting position.</p>
                    <div class="main-button">
                        <a href="#schedule">View Schedule</a>
                    </div>
                  </article>
                  <article id='tabs-2'>
                    <img src="<?php bloginfo('template_directory'); ?>/images/deadlift.jpg" alt="Second Training">
                    <h4>Deadlift</h4>
                    <p>Weightlifting in its purest form is lifting something up and putting it back down. That’s the deadlift in a nutshell. It’s simplicity personified and one of the best muscle-growing, strength-building, health-improving moves around.Here’s how to Deadlift with proper form:

                    1.Stand with your mid-foot under the barbell.  
                    2.Bend over and grab the bar with a shoulder-width grip.  
                    3.Bend your knees until your shins touch the bar.  
                    4.Lift your chest up and straighten your lower back.  
                    5.Take a big breath, hold it, and stand up with the weight. 
                    6.Hold the weight for a second at the top, with locked hips and knees. Then return the weight to the floor by moving your hips back while bending your legs. Rest a second at the bottom and repeat. </p>
                    <div class="main-button">
                        <a href="#schedule">View Schedule</a>
                    </div>
                  </article>
                  <article id='tabs-3'>
                    <img src="<?php bloginfo('template_directory'); ?>/images/press.jpg" alt="Third Class">
                    <h4>Barbell bench press</h4>
                    <p>When you think of weight lifting, a barbell bench press is likely one of the first exercises that comes to mind. You lie on your back and push a barbell up away from your chest. It's a great way to work your chest muscles.Performing the exercise: 
                    1.Set up the bar before lying down.  2.Lie down flat on your back on the bench.  3.Place a leg on either side of the bench. 4. Grab the bar with both hands in an overhand grip.  5.Set your shoulders and pull the bar off the holder.  6.Extend your arms with the bar in your hands.  7.Breathe in and lower the bar down slowly.  8.Breathe out and press up.  9.Keep your hips still as you press up and down.  10.Repeat 8-12 times for one set.</p>
                    <div class="main-button">
                        <a href="#schedule">View Schedule</a>
                    </div>
                  </article>
                  <article id='tabs-4'>
                    <img src="<?php bloginfo('template_directory'); ?>/images/pullup.jpg" alt="Fourth Training">
                    <h4>Pull ups</h4>
                    <p>One of the best exercises for back muscles.Biggest advantage is that you only need a bar and no weights(they are optional).</p>
                    <div class="main-button">
                        <a href="#schedule">View Schedule</a>
                    </div>
                  </article>
                </section>
              </div>
            </div>
        </div>
    </section>
    <!-- ***** Our Classes End ***** -->


    
    <section id = "schedule" class="section" id="schedule">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="section-heading dark-bg">
                        <h2><em>Schedule of our trainers</em></h2>
                        <img src="<?php bloginfo('template_directory'); ?>/images/line-dec.png" alt="">
                        <p>Here you can check when you can contact our trainers for a consultation.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="filters">
                        <ul class="schedule-filter">
                            <li class="active" data-tsfilter="monday">Monday</li>
                            <li data-tsfilter="tuesday">Tuesday</li>
                            <li data-tsfilter="wednesday">Wednesday</li>
                            <li data-tsfilter="thursday">Thursday</li>
                            <li data-tsfilter="friday">Friday</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-10 offset-lg-1">
                    <div class="schedule-table filtering">
                        <table>
                            <tbody>
                                <tr>
                                    
                                    <td class="tuesday ts-item" data-tsmeta="tuesday">8:00AM - 11:45AM</td>
                                    <td class="monday ts-item show" data-tsmeta="monday">1:00PM - 4:30PM</td>
                                    <td>Stanislav Chakarov</td>
                                </tr>
                                <tr>
                                    
                                    <td class="wednesday ts-item" data-tsmeta="wednesday">9:00AM - 11:30AM</td>
                                    <td class="friday ts-item" data-tsmeta="friday">2:00PM - 5:30PM</td>
                                    <td>Nikola Tomov</td>
                                </tr>
                                <tr>
                                    
                                    
                                    <td class=" monday ts-item" data-tsmeta="monday">2:00PM - 6:30PM</td>
                                    
                                    <td class="thursday ts-item" data-tsmeta="thursday">2:00PM - 7:30PM</td>
                                    <td>Radostin Kuzmanov</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ***** Testimonials Starts ***** -->
    <section id = "trainers" class="section" id="trainers">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="section-heading">
                        <h2>Expert <em>Trainers</em></h2>
                        <img src="<?php bloginfo('template_directory'); ?>/images/line-dec.png" alt="">
                        <p>Our trainers are one of the best in Bulgaria so we are sure that you will feel satisfied.</p>
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-lg-4">

                    <div class="trainer-item">
                        <div class="image-thumb">
                            <img src="<?php bloginfo('template_directory'); ?>/images/chakarov.jpeg" alt="">
                        </div>
                        <div class="down-content">
                            <span>Muscle Trainer</span>
                            <h4>Stanislav Chakarov</h4>
                            <p>One of the best muscle trainers in Bulgaria.Co founder of the brand "Aesthetic By Science".</p>
                            <ul class="social-icons">
                                <li><a href="https://www.facebook.com/Aesthetic.Stalik" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                 <li><a href="https://www.instagram.com/stanislav.chakarov/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="trainer-item">
                        <div class="image-thumb">
                            <img 
                            src="<?php bloginfo('template_directory'); ?>/images/nikola.png" alt="">
                        </div>
                        <div class="down-content">
                            <span>Power Trainer</span>
                            <h4>Nikola Tomov</h4>
                            <p>Stanislav Chakarov's partner in "Aesthetic By Science".Also working as a trainer.Focusing his exercises more in power development rather than just muscle size.</p>
                            <ul class="social-icons">
                                <li><a href="https://www.facebook.com/tomovn" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                 <li><a href="https://www.instagram.com/n.tomov/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="trainer-item">
                        <div class="image-thumb">
                            <img src="<?php bloginfo('template_directory'); ?>/images/radostin.jpg" alt="">
                        </div>
                        <div class="down-content">
                            <span>Muscle Trainer</span>
                            <h4>Radostin Kuzmanov</h4>
                            <p>Radostin Kuzmanov is one of the first fitness influencers in Bulgaria.Owner of the "Genezis" company specialized in fitness clothes and accessories.One of the best trainers in Bulgaria.</p>
                            <ul class="social-icons">
                                 <li><a href="https://www.facebook.com/officialRadostinKuzmanov/?ref=page_internal" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                 <li><a href="https://www.instagram.com/radostin_fit/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Testimonials Ends ***** -->
    
    <!-- ***** Contact Us Area Starts ***** -->
    <section class="section" id="contact-us">
        <div class="container-fluid">
            <div class="row">
                
                <?php if(!dynamic_sidebar('right-sidebar')): ?>

<?php endif;?>
                <div class="col-lg-8 col-md-8 col-xs-8">
                    <div id="map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2958.6737488010735!2d24.744766367707182!3d42.13586715166879!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14acd1b39fe79a55%3A0xa6696238f17fc133!2z0J_Rg9C70YEg0YTQuNGC0L3QtdGBINC4INGB0L_QsA!5e0!3m2!1sbg!2sbg!4v1637051612311!5m2!1sbg!2sbg"  width="100%" height="600px" frameborder="0" style="border:0" allowfullscreen loading="lazy"></iframe>
                      <!--<iframe src="https://maps.google.com/maps?q=Av.+L%C3%BAcio+Costa,+Rio+de+Janeiro+-+RJ,+Brazil&t=&z=13&ie=UTF8&iwloc=&output=embed" width="100%" height="600px" frameborder="0" style="border:0" allowfullscreen></iframe> -->
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!-- ***** Contact Us Area Ends ***** -->


       <?php
        get_footer();
   ?>