
<style type="text/css">
	h1{
		text-align: center;
		margin-bottom: 50px !important;
	}
	p{
		font-size: 21px !important;
		margin-top: 50px !important;
		margin-bottom: 20px !important;
		text-align: center;
		font-style: italic;
	}
</style>

<?php

/**
* Template Name: About template
*
*@package WordPress
*@subpackage Twenty_Fourteen
*@since Twenty Fourteen 1.0
*/

	get_header();
?>

<?php

	if(have_posts()){
		while(have_posts()){
			the_post();
		}
	}
?>

<h1>Trust us and the process!</h1>
<div id="content">
	<?php the_content();?>
	<?php echo do_shortcode('[contact-form-7 id="34" title="Форма за контакти 1"]');?>
</div>

<?php


?>


<?php

	get_footer();
?>