    <!-- ***** Footer Start ***** -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; 2021 YourFitnessGuide
                    
                    - Designed by Plamen Gospodinov</p>
                    
                    <!-- You shall support us a little via PayPal to info@templatemo.com -->
                    
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="<?php bloginfo('template_directory'); ?>/js/jquery-2.1.0.min.js"></script>

    <!-- Bootstrap -->
    <script src="<?php bloginfo('template_directory'); ?>/js/popper.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/js/bootstrap.min.js"></script>

    <!-- Plugins -->
    <script src="<?php bloginfo('template_directory'); ?>/js/scrollreveal.min.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/js/waypoints.min.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/js/jquery.counterup.min.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/js/imgfix.min.js"></script> 
    <script src="<?php bloginfo('template_directory'); ?>/js/mixitup.js"></script> 
    <script src="<?php bloginfo('template_directory'); ?>/js/accordions.js"></script>
    
    <!-- Global Init -->
    <script src="<?php bloginfo('template_directory'); ?>/js/custom.js"></script>

  </body>
</html>